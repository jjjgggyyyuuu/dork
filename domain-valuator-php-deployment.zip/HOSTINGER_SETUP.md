# Domain Valuator - Hostinger Setup Instructions 
 
## Secure Configuration Setup 
 
1. After uploading files to Hostinger, create a folder **OUTSIDE** your public_html directory called `config` 
2. Move the `config.php` file to this new directory (e.g., `/home/username/config/config.php`) 
3. Edit `stripe-handler.php` and update the path to the config file: 
 
   ```php 
   // Change this line: 
   $config = include_once '../config.php'; 
 
   // To your actual config path, for example: 
   $config = include_once '/home/username/config/config.php'; 
   ``` 
 
4. Update the values in the config.php file with your actual Stripe API keys 
5. Set permissions on the config directory: `chmod 750 /home/username/config` 
6. Set permissions on the config file: `chmod 640 /home/username/config/config.php` 
 
## Testing Your Setup 
 
1. Visit `https://yourdomain.com/test.php` to verify your PHP configuration 
2. To test Stripe integration, attempt a subscription from the main page 
3. Use Stripe test cards (like 4242 4242 4242 4242) for testing payments 
4. Check if webhooks are properly configured in your Stripe Dashboard 
 
## Troubleshooting 
 
- If you see a blank page, check PHP error logs in Hostinger control panel 
- Make sure `mod_rewrite` is enabled on your Hostinger server 
- If Stripe payments aren't working, verify API keys in config.php 
- Ensure .htaccess file was properly uploaded and Hostinger supports it 
