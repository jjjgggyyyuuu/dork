<?php phpinfo(); ?> 
